clear all
close all
clc

format long;


tarRightPercent_3Bl=zeros(3,14);
PID = [ 1:4, 6:9,11,12,14:34];
Arm_L = xlsread('SubjectsAL.xlsx');
AllSubjectsData=zeros(1,26);
for pid = 1:2%length(PID)
% new code for data organization
OrgData = zeros(500, 26)+10000;
orderType = rem(PID(pid),2);%input(prompt1);
armLength = Arm_L(pid,1);%input(prompt2);

shoulderHeight = Arm_L(pid,2);%input (prompt3);

sin55=0.5000; cos55=0.8660;sin30=0.2588; cos30=0.9659; 
sin174=0.1219; cos174=0.9926; sin0=0; cos0= 1; percent=0.8;

sinArmAngle = 0.5;
cosArmAngle = 0.866;

for block=1:5
%% Jenny    
    for ti = 1 :14 
        eval(['T' num2str(ti) '_B' num2str(block) 'L=[];']);
        eval(['T' num2str(ti) '_B' num2str(block) 'R=[];']);
    end
%%
    disp('block is');
    disp(block);
    if PID(pid) < 10
        spid = ['0' num2str(PID(pid))];
    else
        spid = num2str(PID(pid));
    end
    %FP = [ 'C:\Users\jingw\Documents\MATLAB\Renamed VR testing Data\*_P' spid '_b0' num2str(block) '.xdf'];
    FP = [ '*_P' spid '_b0' num2str(block) '.xdf'];
    NF= dir(FP);
    data = load_xdf([ NF.name ]);

[a,b]=size (data);
s_S='S';
s_L='L'; 
s_R='R';
s_C='C';
s_H='H';
for i=1:b
   if (strncmp(s_S, data{i}.info.name,1))
       spawnData=data{i}.time_series; % has the targetID information
       spawnTime=data{i}.time_stamps; % has the task StartTime info
   elseif (strncmp(s_L, data{i}.info.name,1))
       leftTransform=data{i}.time_series; %4, 5, 6 rows are x, y, and z
       leftTransTime=data{i}.time_stamps;
   elseif (strncmp(s_R, data{i}.info.name,1))
       rightTransform = data{i}.time_series; %4, 5, 6 rows are x, y, and z
       rightTransTime=data{i}.time_stamps;
   elseif (strncmp(s_C, data{i}.info.name,1))
       centEyeTransform = data{i}.time_series;
       centEyeTransTime=data{i}.time_stamps;
   elseif (strncmp(s_H, data{i}.info.name,1))
       collisionData=data{i}.time_series;
       collisionTime=data{i}.time_stamps;
   end
end

if ((pid==12)&&(block==2))
    collisionData(79:80)=[];
    collisionTime(79:80)=[];
end

% new code to put blockNum, trialNum, StartTime to the OrgData matrix

for idx=1:100
    OrgData((idx+(block-1)*100),23)=PID(pid); % put the blockNum to the first column of the OrgData matrix
    OrgData((idx+(block-1)*100),1)=block; % put the blockNum to the first column of the OrgData matrix
    OrgData((idx+(block-1)*100),2)= idx;% put the trialNum to the 2nd column of the OrgData 
    OrgData((idx+(block-1)*100),3)= spawnTime(idx); % put the startTime to the 3rd column of the OrgData
    % put x, y, z starting positions of both hands to the OrgData matrix
    timeArray=find(leftTransTime<spawnTime(idx));
    timeIdx=max(timeArray);
    OrgData((idx+(block-1)*100),10)= leftTransform(4,timeIdx); %left hand x to 10th column
    OrgData((idx+(block-1)*100),11)= leftTransform(5,timeIdx); %left hand y to 11th column
    OrgData((idx+(block-1)*100),12)= leftTransform(6,timeIdx); %left hand z to 12th column
    OrgData((idx+(block-1)*100),13)= rightTransform(4,timeIdx); %right hand x to 13th column
    OrgData((idx+(block-1)*100),14)= rightTransform(5,timeIdx); %right hand y to 14th column
    OrgData((idx+(block-1)*100),15)= rightTransform(6,timeIdx); %right hand z to 15th column
    
    if idx==1
        timeArrayC=find(leftTransTime<(spawnTime(idx)-5));
        timeIdx_C=max(timeArrayC);%CaliX of that block to the 16th column
        OrgData((idx+(block-1)*100),16)= centEyeTransform (4,timeIdx_C);
    else
        OrgData((idx+(block-1)*100),16)= OrgData((idx-1+(block-1)*100),16);
    end  
end
% transform right hand monitoring data to virtual right hand data
caliTime= OrgData((1+(block-1)*100),3)-5;
caliIdx= find(rightTransTime<caliTime,1,'last');
x0=rightTransform(4,caliIdx);
y0=rightTransform(5,caliIdx);
z0=rightTransform(6,caliIdx);
if (((orderType==1)&&(block==2))||((orderType==0)&&(block==4)))
   %ampIdx=1.5;
    V_Px= (rightTransform(4,:)-x0)*1.5+x0;
    V_Py= (rightTransform(5,:)-y0)*1.5+y0;
    V_Pz= (rightTransform(6,:)-z0)*1.5+z0;
    V_rightTransform =[V_Px; V_Py; V_Pz];
elseif (((orderType==1)&&(block==4))||((orderType==0)&&(block==2)))
   %ampIdx=2;
    V_Px= (rightTransform(4,:)-x0)*2+x0;
    V_Py= (rightTransform(5,:)-y0)*2+y0;
    V_Pz= (rightTransform(6,:)-z0)*2+z0;
    V_rightTransform =[V_Px; V_Py; V_Pz];
else
    %V_rightTransform = rightTransform(4:6,:); 
    V_Px= (rightTransform(4,:)-x0)*1+x0;
    V_Py= (rightTransform(5,:)-y0)*1+y0;
    V_Pz= (rightTransform(6,:)-z0)*1+z0;
    V_rightTransform =[V_Px; V_Py; V_Pz];
end


%check whether the amount of data items equals to 100
[m,n]= size (spawnData); % m=1
% correctNumber= (n==100);
% display(correctNumber);

%find L1 in the data array, count L1 frequency, and then loop to L14. add
%the frequency info of all locations to an array
tarList=["TL1","TL2","TL3","TL4","TL5","TL6","TL7","TL8","TL9","TL10","TL11","TL12","TL13","TL14"];
tarFreq=zeros(1,14);
%tarResult=cell(2,14);

for i=1:14
    s = tarList(i);
    for ii=1:n
        if(strcmp(s, spawnData(ii)))
            tarFreq(i)=tarFreq(i)+1;
        end   
    end
    %tarResult(1,i)=s;
    %tarResult(2,i)=tarFreq(i);
end

%disp('Targets frequency in different locations');
%disp(tarFreq);   

angleFreq=zeros(1,7);
highTarFreq=zeros(1,7);
lowTarFreq=zeros(1,7);
for i=1:7
    angleFreq(i)= tarFreq(1,(2*i-1))+ tarFreq(1,2*i);
    highTarFreq(i)= tarFreq(1,(2*i-1));
    lowTarFreq(i)= tarFreq(1,2*i);
end

disp('Targets frequency in the angle based locations:');
disp(angleFreq);

disp('Targets frequency in the higher level locations:');
disp(highTarFreq);

disp('Targets frequency in the lower level locations:');
disp(lowTarFreq);


%plot the frequency of all locations   wait to implement
%new code to add the peak velocity
% ss1='L';
% ss2='R';
% for i=1:5
%    if (strncmp(ss1, data{i}.info.name, 1))
%        I =data{i}.time_series; %left hand   leftTransform=I
%        T = data{i}.time_stamps; %leftTransTime=T
%    end
%    
%    if (strncmp(ss2, data{i}.info.name, 1))
%        I2 =data{i}.time_series; %right hand rightTransform=I2
%        T2 = data{i}.time_stamps;  % rightTransTime=T2   
%    end  
% end

I=leftTransform;
T=leftTransTime;
I2=rightTransform;
T2=rightTransTime;

Dt = sqrt((I(4,3:end)-I(4,1:(end-2))).^2 +(I(5,3:end)-I(5,1:(end-2))).^2+(I(6,3:end)-I(6,1:(end-2))).^2)*1000;
D1 = sqrt((I(4,2)-I(4,1)).^2 +(I(5,2)-I(5,1)).^2+(I(6,2)-I(6,1)).^2)*1000;
D2 = sqrt((I(4,end)-I(4,end-1)).^2 +(I(5,end)-I(5,end-1)).^2+(I(6,end)-I(6,end-1)).^2)*1000;
dt1 = T(2)-T(1);
dt = T(3:end)-T(1:(end-2));
dt2 = T(end)-T(end-1);
D=[D1 Dt D2];
V=[D1/dt1 Dt./dt D2/dt2];

Fs=90; Fc=4;
[Bf,Af]=butter(3,Fc/(Fs/2));
leftV_filt=filtfilt(Bf,Af,V);

Dt = sqrt((I2(4,3:end)-I2(4,1:(end-2))).^2 +(I2(5,3:end)-I2(5,1:(end-2))).^2+(I2(6,3:end)-I2(6,1:(end-2))).^2)*1000;
D1 = sqrt((I2(4,2)-I(4,1)).^2 +(I2(5,2)-I(5,1)).^2+(I2(6,2)-I(6,1)).^2)*1000;
D2 = sqrt((I2(4,end)-I2(4,end-1)).^2 +(I2(5,end)-I2(5,end-1)).^2+(I2(6,end)-I2(6,end-1)).^2)*1000;
dt1_r = T2(2)-T2(1);
dt_r = T2(3:end)-T2(1:(end-2));
dt2_r = T2(end)-T2(end-1);
D=[D1 Dt D2];
V_r=[D1/dt1_r Dt./dt_r D2/dt2_r];

Fs=90; Fc=4;
[Bf,Af]=butter(3,Fc/(Fs/2));
rightV_filt=filtfilt(Bf,Af,V_r);
%figure (4),plot(V);
%T2 = T2(1:end) - min(T2);


% new code. To add collisionTime and completion time to OrgData
for idx=1:100 
    OrgData((idx+(block-1)*100),4)= collisionTime(1,(2*idx-1));% put collisionTime data to the 4th column of OrgData
    OrgData((idx+(block-1)*100),9)= OrgData((idx+(block-1)*100),4)- OrgData((idx+(block-1)*100),3); % calulate completion time for each reaching tial, to 9th column of OrgData
    
    temp= collisionData{2*idx};
    targetID = temp(3:end);
    OrgData((idx+(block-1)*100),5)= str2double(targetID);  % put targetID to the 5th column of the OrgData
    s="L";
    if (strncmp(s, collisionData((2*idx-1)),1))  % right hand or left hand to the 6th column of the OrgData
        OrgData((idx+(block-1)*100),6)= 0; % left hand
    else
        OrgData((idx+(block-1)*100),6)= 1; % right hand
    end
    
        %new code Calculate target location, and put x, y, z to 17, 18, 19 column
    targetID = OrgData((idx+(block-1)*100),5);
    switch targetID
        case 1
           OrgData((idx+(block-1)*100),17)=(-sin55) * percent * armLength * cosArmAngle-OrgData((idx+(block-1)*100),16);
           OrgData((idx+(block-1)*100),18)=shoulderHeight + percent * armLength * sinArmAngle;
           OrgData((idx+(block-1)*100),19)=cos55 * percent * armLength * cosArmAngle-0.75;
        case 2
           OrgData((idx+(block-1)*100),17)=(-sin55) * percent * armLength-OrgData((idx+(block-1)*100),16);
           OrgData((idx+(block-1)*100),18)=shoulderHeight;
           OrgData((idx+(block-1)*100),19)=cos55 * percent * armLength-0.75;
        case 3
           OrgData((idx+(block-1)*100),17)=(-sin30) * percent * armLength * cosArmAngle -OrgData((idx+(block-1)*100),16);
           OrgData((idx+(block-1)*100),18)=shoulderHeight + percent * armLength * sinArmAngle;
           OrgData((idx+(block-1)*100),19)=cos30 * percent * armLength * cosArmAngle-0.75;
        case 4
           OrgData((idx+(block-1)*100),17)=(-sin30) * percent * armLength -OrgData((idx+(block-1)*100),16);
           OrgData((idx+(block-1)*100),18)= shoulderHeight;
           OrgData((idx+(block-1)*100),19)=cos30 * percent * armLength-0.75;
        case 5
           OrgData((idx+(block-1)*100),17)=(-sin174) * percent * armLength * cosArmAngle -OrgData((idx+(block-1)*100),16);
            OrgData((idx+(block-1)*100),18)=shoulderHeight + percent * armLength * sinArmAngle;
            OrgData((idx+(block-1)*100),19)=cos174 * percent * armLength * cosArmAngle-0.75;
        case 6
            OrgData((idx+(block-1)*100),17)=(-sin174) * percent * armLength -OrgData((idx+(block-1)*100),16);
            OrgData((idx+(block-1)*100),18)=shoulderHeight;
            OrgData((idx+(block-1)*100),19)=cos174 * percent * armLength -0.75;
        case 7
            OrgData((idx+(block-1)*100),17)=sin0 * percent * armLength * cosArmAngle -OrgData((idx+(block-1)*100),16);
            OrgData((idx+(block-1)*100),18)=shoulderHeight + percent * armLength * sinArmAngle;
            OrgData((idx+(block-1)*100),19)=cos0 * percent * armLength * cosArmAngle-0.75;
        case 8
            OrgData((idx+(block-1)*100),17)=sin0 * percent * armLength -OrgData((idx+(block-1)*100),16);
            OrgData((idx+(block-1)*100),18)=shoulderHeight;
            OrgData((idx+(block-1)*100),19)=cos0 * percent * armLength -0.75;
        case 9
            OrgData((idx+(block-1)*100),17)=sin174 * percent * armLength * cosArmAngle -OrgData((idx+(block-1)*100),16);
            OrgData((idx+(block-1)*100),18)=shoulderHeight + percent * armLength * sinArmAngle;
            OrgData((idx+(block-1)*100),19)=cos174 * percent * armLength * cosArmAngle-0.75;
        case 10
            OrgData((idx+(block-1)*100),17)=sin174 * percent * armLength -OrgData((idx+(block-1)*100),16);
            OrgData((idx+(block-1)*100),18)=shoulderHeight;
            OrgData((idx+(block-1)*100),19)=cos174 * percent * armLength -0.75;
        case 11
            OrgData((idx+(block-1)*100),17)=sin30 * percent * armLength * cosArmAngle -OrgData((idx+(block-1)*100),16);
            OrgData((idx+(block-1)*100),18)=shoulderHeight + percent * armLength * sinArmAngle;
            OrgData((idx+(block-1)*100),19)=cos30 * percent * armLength * cosArmAngle-0.75;
        case 12
            OrgData((idx+(block-1)*100),17)=sin30 * percent * armLength -OrgData((idx+(block-1)*100),16);
            OrgData((idx+(block-1)*100),18)=shoulderHeight;
            OrgData((idx+(block-1)*100),19)=cos30 * percent * armLength-0.75;
        case 13
            OrgData((idx+(block-1)*100),17)=sin55 * percent * armLength * cosArmAngle -OrgData((idx+(block-1)*100),16);
            OrgData((idx+(block-1)*100),18)=shoulderHeight + percent * armLength * sinArmAngle;
            OrgData((idx+(block-1)*100),19)=cos55 * percent * armLength * cosArmAngle-0.75;
        case 14
            OrgData((idx+(block-1)*100),17)=sin55 * percent * armLength -OrgData((idx+(block-1)*100),16);
            OrgData((idx+(block-1)*100),18)=shoulderHeight;
            OrgData((idx+(block-1)*100),19)=cos55 * percent * armLength-0.75;
        otherwise
            disp('The value of targetID is not valid. ')
    end
    
    % add code to calulate path length ratio
    %st_point = find(leftTransTime<OrgData((idx+(block-1)*100),3),1,'last');
    %ed_point =  find(leftTransTime<OrgData((idx+(block-1)*100),4),1,'last');
    
    x_Ls=OrgData((idx+(block-1)*100),10); % Left hand starting point
    y_Ls=OrgData((idx+(block-1)*100),11);
    z_Ls=OrgData((idx+(block-1)*100),12);
    x_Rs=OrgData((idx+(block-1)*100),13); % Right Hand starting point
    y_Rs=OrgData((idx+(block-1)*100),14);
    z_Rs=OrgData((idx+(block-1)*100),15);
    x_t=OrgData((idx+(block-1)*100),17);% target location
    y_t=OrgData((idx+(block-1)*100),18);
    z_t=OrgData((idx+(block-1)*100),19);
    
    if (OrgData((idx+(block-1)*100),6)==0)% left hand
        st_point = find(leftTransTime<OrgData((idx+(block-1)*100),3),1,'last');
        ed_point =  find(leftTransTime<OrgData((idx+(block-1)*100),4),1,'last');
        
        %new code for peak Velocity and rectTime2 Thanh look here
%% Jenny
        for ti= 1:14   
            if OrgData((idx+(block-1)*100),5) == ti
                eval(['ind=size(T' num2str(ti) '_B' num2str(block) 'L,2);'])
                if ind == 0
                    eval(['T' num2str(ti) '_B' num2str(block) 'L=leftV_filt(st_point:ed_point);']);
                else
                    eval(['T' num2str(ti) '_B' num2str(block) 'L=[T' num2str(ti) '_B' num2str(block)  'L leftV_filt(st_point:ed_point)];']);
                end
            end
            
        end
%%
        OrgData((idx+(block-1)*100),7)= max(leftV_filt(st_point:ed_point)); % actual peak velocity to 7th column
        
        OrgData((idx+(block-1)*100),8)= OrgData((idx+(block-1)*100),7); % virtual peak velocity eaquals to actual one for left hand, to the 8th column
        for k=1:(ed_point-st_point)
            if leftV_filt(st_point+k)>0.05*OrgData((idx+(block-1)*100),7)
                reacTime2= leftTransTime(st_point+k)- OrgData((idx+(block-1)*100),3);
                %OrgData((idx+(block-1)*100),22)=reacTime2;
                break
            end
        end
        
        
        
        distance= sqrt((OrgData((idx+(block-1)*100),10)-OrgData((idx+(block-1)*100),17))^2+(OrgData((idx+(block-1)*100),11)-OrgData((idx+(block-1)*100),18))^2+(OrgData((idx+(block-1)*100),12)- OrgData((idx+(block-1)*100),19))^2);
        P= leftTransform (4:6,st_point:ed_point);
        if (length(P)<1)
            continue
        end
        %[x,dim]=size(P(1,:));
        %PP=zeros(1,dim);
        distance3=sqrt((P(1,end) - P(1,1)).^2+(P(2,end) - P(2,1)).^2+(P(3,end) - P(3,1)).^2);
        %PP(1,1)= sqrt((P(1,1)-OrgData((idx+(block-1)*100),10))^2 +(P(2,1)-OrgData((idx+(block-1)*100),11))^2+(P(3,1)-OrgData((idx+(block-1)*100),12))^2);
        %for i=2:dim
            %PP(1,i)= sqrt((P(4,i)-P(4,i-1))^2 +(P(5,i)- P(5,i-1))^2+(P(6,i)-P(6,i-1))^2);
        %end
        PP2 = sqrt((P(1,2:end) - P(1,1:(end-1))).^2+(P(2,2:end) - P(2,1:(end-1))).^2+(P(3,2:end) - P(3,1:(end-1))).^2);
        %PP= [PP(1,1) PP2];
        pathL=sum(PP2, 'all');
        ratio=pathL/distance; % path length ratio to the 21 column of the OrgData, using target center as end point
        ratio3=pathL/distance3; % path length ratio using hand end point as end point
        OrgData((idx+(block-1)*100),21)=ratio;
        %OrgData((idx+(block-1)*100),22)=ratio;
        OrgData((idx+(block-1)*100),24)=ratio3;
        
        centerDistance=sqrt((P(1,end) - x_t).^2+(P(2,end) - y_t).^2+(P(3,end) - z_t).^2);
        OrgData((idx+(block-1)*100),25)=centerDistance;
        OrgData((idx+(block-1)*100),26)=centerDistance;
        
        %calulate the reaction time
        PP3= sqrt((P(1,1:end) - OrgData((idx+(block-1)*100),10)).^2+(P(2,1:end) - OrgData((idx+(block-1)*100),11)).^2+(P(3,1:end) - OrgData((idx+(block-1)*100),12)).^2); %left hand distance to it's resting position
        dMax= max(PP3);
        thresh1=0.05*dMax;
        %thresh2=0.05*(OrgData((idx+(block-1)*100),7);
        for k=1:(ed_point-st_point)
            if PP3(k)>thresh1
                reacTime1 = leftTransTime(st_point+k)- OrgData((idx+(block-1)*100),3);
                OrgData((idx+(block-1)*100),20)=reacTime1;
                OrgData((idx+(block-1)*100),22)=dMax;
                %k= ed_point-st_point+1;
                break
            end
        end

    else %right hand
        %distance= sqrt((OrgData((idx+(block-1)*100),13)-OrgData((idx+(block-1)*100),17))^2+(OrgData((idx+(block-1)*100),14)-OrgData((idx+(block-1)*100),18))^2+(OrgData((idx+(block-1)*100),15)- OrgData((idx+(block-1)*100),19))^2);
        st_point = find(rightTransTime<OrgData((idx+(block-1)*100),3),1,'last');
        ed_point =  find(rightTransTime<OrgData((idx+(block-1)*100),4),1,'last');
        
        OrgData((idx+(block-1)*100),7)= max(rightV_filt(st_point:ed_point));
        if (((orderType==1)&&(block==2))||((orderType==0)&&(block==4)))
            OrgData((idx+(block-1)*100),8)= OrgData((idx+(block-1)*100),7)*1.5; % virtual peak velocity eaquals to actual one *1.5 for right hand
        elseif (((orderType==1)&&(block==4))||((orderType==0)&&(block==2)))
            OrgData((idx+(block-1)*100),8)= OrgData((idx+(block-1)*100),7)*2;
        else
            OrgData((idx+(block-1)*100),8)=OrgData((idx+(block-1)*100),7);   
        end
        %% Jenny
        for ti= 1:14   
            if OrgData((idx+(block-1)*100),5) == ti
                eval(['ind=size(T' num2str(ti) '_B' num2str(block) 'R,2);'])
                if ind == 0
                    eval(['T' num2str(ti) '_B' num2str(block) 'R=rightV_filt(st_point:ed_point);']);
                else
                    eval(['T' num2str(ti) '_B' num2str(block) 'R=[T' num2str(ti) '_B' num2str(block)  'R rightV_filt(st_point:ed_point)];']);
                end
            end     
        end
        %%
        for k=1:(ed_point-st_point)
            if rightV_filt(st_point+k)>0.05*OrgData((idx+(block-1)*100),7)
                reacTime2= rightTransTime(st_point+k)- OrgData((idx+(block-1)*100),3);
                %OrgData((idx+(block-1)*100),22)=reacTime2;
                break
            end
        end
        
        P=rightTransform (4:6,st_point:ed_point);
        if (length(P)<1)
            continue
        end
        vP=V_rightTransform(:,st_point:ed_point);
       
         if (((orderType==1)&&(block==2))||((orderType==0)&&(block==4)))
            x_tr=(x_t-x0)/1.5+x0; 
            y_tr=(y_t-y0)/1.5+y0;
            z_tr=(z_t-z0)/1.5+z0;
        elseif (((orderType==1)&&(block==4))||((orderType==0)&&(block==2)))
            x_tr=(x_t-x0)/2+x0; 
            y_tr=(y_t-y0)/2+y0;
            z_tr=(z_t-z0)/2+z0;
        else
            x_tr=(x_t-x0)/1+x0; 
            y_tr=(y_t-y0)/1+y0;
            z_tr=(z_t-z0)/1+z0;
        end
        
        %PP(1,1)= sqrt((vP(1,1)-OrgData((idx+(block-1)*100),13))^2 +(vP(2,1)-OrgData((idx+(block-1)*100),14))^2+(vP(3,1)-OrgData((idx+(block-1)*100),15))^2);
        PP2 = sqrt((vP(1,2:end) - vP(1,1:(end-1))).^2+(vP(2,2:end) - vP(2,1:(end-1))).^2+(vP(3,2:end) - vP(3,1:(end-1))).^2);
        %PP= [PP(1,1) PP2];
        %pathL=sum(PP, 'all');
        pathL_v=sum(PP2,'all');
        distance1=sqrt((x_t - vP(1,1)).^2+(y_t - vP(2,1)).^2+(z_t - vP(3,1)).^2);
        distance3=sqrt((vP(1,end) - vP(1,1)).^2+(vP(2,end) - vP(2,1)).^2+(vP(3,end) - vP(3,1)).^2);
        ratio1=pathL_v/distance1
        ratio3=pathL_v/distance3;  
        OrgData((idx+(block-1)*100),21)=ratio1; 
        OrgData((idx+(block-1)*100),24)=ratio3;
        
        centerDistance1=sqrt((vP(1,end) - x_t).^2+(vP(2,end) - y_t).^2+(vP(3,end) - z_t).^2);
        OrgData((idx+(block-1)*100),25)=centerDistance1;
        
        centerDistance2=sqrt((P(1,end) - x_tr).^2+(P(2,end) - y_tr).^2+(P(3,end) - z_tr).^2);
        OrgData((idx+(block-1)*100),26)=centerDistance2;
%          if (((orderType==1)&&(block==2))||((orderType==0)&&(block==4)))
%             OrgData((idx+(block-1)*100),21)= ratio*1.5; 
%         elseif (((orderType==1)&&(block==4))||((orderType==0)&&(block==2)))
%             OrgData((idx+(block-1)*100),21)= ratio*2;
%         else
%             OrgData((idx+(block-1)*100),21)=ratio;   
%         end
        
        %calulate the reaction time
        
        
        % new code to calulated real distance, ratio2
        
       
  
        distance2=sqrt((x_tr-x_Rs)^2+(y_tr-y_Rs)^2+(z_tr-z_Rs)^2);
        %distance2= sqrt((P(1,end) - P(1,1)).^2+(P(2,end) - P(2,1)).^2+(P(3,end) - P(3,1)).^2);
        Path2P = sqrt((P(1,2:end) - P(1,1:(end-1))).^2+(P(2,2:end) - P(2,1:(end-1))).^2+(P(3,2:end) - P(3,1:(end-1))).^2);
        path2L=sum(Path2P,'all');
        ratio2=path2L/distance2;
        %OrgData((idx+(block-1)*100),22)=ratio2;
        
        
        PP4= sqrt((P(1,1:end) - OrgData((idx+(block-1)*100),13)).^2+(P(2,1:end) - OrgData((idx+(block-1)*100),14)).^2+(P(3,1:end) - OrgData((idx+(block-1)*100),15)).^2); %right hand distance to it's resting position
        dMax= max(PP4);
        thresh1=0.05*dMax;
        %PP5= sqrt((vP(1,1:end) - OrgData((idx+(block-1)*100),13)).^2+(vP(2,1:end) - OrgData((idx+(block-1)*100),14)).^2+(vP(3,1:end) - OrgData((idx+(block-1)*100),15)).^2);
        %dMax_V=max(PP5);
        %thresh2=0.05*(OrgData((idx+(block-1)*100),7);
        for k=1:(ed_point-st_point)
            if PP4(k)>thresh1
                reacTime1 = rightTransTime(st_point+k)- OrgData((idx+(block-1)*100),3);
                OrgData((idx+(block-1)*100),20)=reacTime1;
                OrgData((idx+(block-1)*100),22)=dMax;
                %k= ed_point-st_point+1;
                break
            end
        end
        
        %3D plot part
 %{       
        if (block==4)&&(OrgData((idx+(block-1)*100),5)==12)
            figure (1)
            %plot3(P(1,:),P(2,:),P(3,:));
            %hold on
            plot3(vP(1,:),vP(2,:),vP(3,:));
            hold on
            %PL_v=[vP(1,1),x_t;vP(2,1),y_t;vP(3,1),z_t];
            %plot3(PL_v(1,:),PL_v(2,:),PL_v(3,:));
            %hold on
            %PL2=[x_Rs,x_tr;y_Rs,y_tr;z_Rs,z_tr];
            %plot3(PL2(1,:),PL2(2,:),PL2(3,:));
            %hold on
            PL3=[vP(1,1),vP(1,end);vP(2,1),vP(2,end);vP(3,1),vP(3,end)];
            plot3(PL3(1,:),PL3(2,:),PL3(3,:));
            hold on
            %PL4=[P(1,1),P(1,end);P(2,1),P(2,end);P(3,1),P(3,end)];
            %plot3(PL4(1,:),PL4(2,:),PL4(3,:));
            grid on
            axis equal
        end
  %}     
    end
   
end


%below to be commented
%{

% new code. search for actual and virtual peak velocity of each reaching trial
for idx=1:100 
    if (idx>99)% when i=100
        L_idx_big=find(T<(spawnTime(idx)+3));
        L_idx_sml=find (T<spawnTime(idx));
    else
        L_idx_big=find(T<spawnTime(idx+1));
        L_idx_sml=find (T<spawnTime(idx));
    end
    
    L_a=max(L_idx_sml);
    L_b=max(L_idx_big);
    %R_idx_big=find(T2<spawnTime(i+1)); % commented this part because the
                              %time_stamps for left hand and right hand are the same
    %R_idx_sml=find(T2<spawnTime(i));
    %R_a=max(R_idx_big);
    %R_b=max(R_idx_sml);
    
    if (OrgData((idx+(block-1)*100),6)==0) % if left hand is the active hand for that reaching trial
        OrgData((idx+(block-1)*100),7)= max(V(L_a:L_b)); % actual peak velocity to 7th column
        OrgData((idx+(block-1)*100),8)= OrgData((idx+(block-1)*100),7); % virtual peak velocity eaquals to actual one for left hand, to the 8th column
        
        for k=1:(L_b-L_a)
            if V(k)>0.05*OrgData((idx+(block-1)*100),7)
                reacTime2= leftTransTime(L_a+k)- OrgData((idx+(block-1)*100),3);
                %OrgData((idx+(block-1)*100),22)=reacTime2;
                %k=L_b-L_a+1;
                break
            end
        end
    else % right hand is the reaching hand for that trial
        OrgData((idx+(block-1)*100),7)= max(V_r(L_a:L_b));
        if (((orderType==1)&&(block==2))||((orderType==0)&&(block==4)))
            OrgData((idx+(block-1)*100),8)= OrgData((idx+(block-1)*100),7)*1.5; % virtual peak velocity eaquals to actual one *1.5 for right hand
        elseif (((orderType==1)&&(block==4))||((orderType==0)&&(block==2)))
            OrgData((idx+(block-1)*100),8)= OrgData((idx+(block-1)*100),7)*2;
        else
            OrgData((idx+(block-1)*100),8)=OrgData((idx+(block-1)*100),7);   
        end
        
        for k=1:(L_b-L_a)
            if V_r(k)>0.05*OrgData((idx+(block-1)*100),7)
                reacTime2= leftTransTime(L_a+k)- OrgData((idx+(block-1)*100),3);
                %OrgData((idx+(block-1)*100),22)=reacTime2;
                %k=L_b-L_a+1;
                break
            end
        end
    end
    
    OrgData((idx+(block-1)*100),9)= OrgData((idx+(block-1)*100),4)- OrgData((idx+(block-1)*100),3); % calulate completion time for each reaching tial, to 9th column of OrgData
end
%}
% above to be commented

%new code to put starting hand positions for each trial 


[mm,nn]= size (collisionData);
%search "Left Hand" in the collision data, count the frequency, and make a
%sub-array for the left hand collision data
leftCount=0;
leftColliTar=strings(1,100);
leftColliTime=zeros(1,100);
s="Left Hand";
for i=1:nn
   if (strncmp(s, collisionData(i),9))      
       leftCount=leftCount+1;
       leftColliTar(leftCount)= collisionData(1,(i+1));
       leftColliTime(leftCount)= collisionTime(1,i);
   end
end 

leftColliTar= leftColliTar(1:leftCount); % remove the nonused array slots
leftColliTime= leftColliTime(1:leftCount);
leftPercent = leftCount/100;
disp('Left hand percentage among this experimental block is:');
disp(leftPercent);
%disp(leftColliTar);

%search "Right Hand" in the collision data, count the frequency, and make a
%sub-array for the right hand collision data
rightCount=0;
rightColliTar=strings(1,100);
rightColliTime=zeros(1,100);
s='Right Hand';
for i=1:nn
   if (strncmp(s, collisionData(1,i),10))      
       rightCount=rightCount+1;
       rightColliTar(rightCount)= collisionData(1,(i+1));
       rightColliTime(rightCount)= collisionTime(1,i);
   end
end 

rightColliTar= rightColliTar(1:rightCount); % remove the nonused array slots
rightColliTime= rightColliTime(1:rightCount);
rightPercent = rightCount/100;
disp('Right hand percentage among this experimental block is:');
disp(rightPercent); %calulate and print the right hand percentage within this whole block
%disp(rightColliTar);


%plot the left hand percentage and right hand persentage of the block



%section 3: find L1 in the left hand collision data and count the frequency
tarList=["TL1","TL2","TL3","TL4","TL5","TL6","TL7","TL8","TL9","TL10","TL11","TL12","TL13","TL14"];
tarC_L=zeros(1,14); %left hand collision frequency for each Target
tarC_R=zeros(1,14); %right hand collision frequency for each Target
tarRightPercent= zeros(1,14);%right hand percent for each target

for i=1:14
    s = tarList(i);
    % loop this process to L14 and record the results in an array C-L
    for ii=1:leftCount 
        if(strcmp(s, leftColliTar(ii)))
            tarC_L(i)=tarC_L(i)+1;
        end   
    end
  
    % find L1 to L14, same as the above process, in right hand collision data
    % C-R
    for ii=1:rightCount 
        if(strcmp(s, rightColliTar(ii)))
            tarC_R(i)=tarC_R(i)+1;
        end   
    end
% calulate the right hand percentage for each location by C-R/(C-L+C-R), 
%L1-L14, and save the results to an array
    tarRightPercent(i)=tarC_R(i)/(tarC_R(i)+tarC_L(i));
end

%disp(tarC_L);
%disp(tarC_R);
%disp(tarRightPercent);

highRightPercent=zeros(1,7);
lowRightPercent=zeros(1,7);
for i=1:7
    highRightPercent(i)= tarRightPercent(1,(2*i-1));
    lowRightPercent(i)= tarRightPercent(1,2*i);
end

disp('Right hand percentage for the higher level targets:');
disp(highRightPercent);

disp('Right hand percentage for the shoulder level targets:');
disp(lowRightPercent);





% plot this array

%section 4: reaction time and completion time calculation
% s1='R'
% s2='L';
% for i=1:5
%    if (strncmp(s1, data{i}.info.name,1))
%        rightHandX=data{i}.time_series(4,:);
%        rightHandY=data{i}.time_series(5,:);
%        rightHandZ=data{i}.time_series(6,:);
%        rightHandTime=data{i}.time_stamps;
%        
%    elseif (strncmp(s2, data{i}.info.name,1))
%        leftHandX=data{i}.time_series(4,:);
%        leftHandY=data{i}.time_series(5,:);
%        leftHandZ=data{i}.time_series(6,:);
%        leftHandTime=data{i}.time_stamps;  
%        
%    %else
%        %disp('Cannot get hand transform data.');
%    end
% 
% end

%find the first target in spawn data
% reactionTime=zeros(2,n); %(2,:)is used to record left hand or right hand
% completionTime=zeros(2,n); % 0=left hand; 1=right hand
% handIndex=1;
% alpha=100000;
% thresh=0.005;
% for i=1:n
%     startTime=spawnTime(1,i);
%     endTime=collisionTime(1,(2*i-1));
%     completionTime(1,i)=endTime-startTime;
%     if (strncmp(s1,collisionData(1,(2*i-1)),1)) %right hand is the moving hand
%         for ii=handIndex:alpha
%             if (rightHandTime(ii)> startTime)
%                 a=ii-1; 
%                 restX=rightHandX(ii-1);
%                 restY=rightHandY(ii-1);
%                 restZ=rightHandZ(ii-1);
%                 break;
%             end          
%         end
%         
%         for iii=a:alpha
%             disX=abs(rightHandX(iii)-restX);
%             disY=abs(rightHandY(iii)-restY);
%             disZ=abs(rightHandZ(iii)-restZ);
%             if ((disX>=thresh)||(disY>=thresh)||(disZ>=thresh))
%                 reactionTime(1,i)=rightHandTime(iii)-startTime;
%                 reactionTime(2,i)=1;% 1 means right hand here.
%                 completionTime(2,i)=1; % 1 means right hand here.
%                 b=iii;
%                 break;
%             end
%         end
%         
%         
%     elseif (strncmp(s2,collisionData(1,(2*i-1)),1)) %left hand is the moving hand
%         for ii=handIndex:alpha
%             if (leftHandTime(ii)> startTime)
%                 a=ii-1; 
%                 restX=leftHandX(ii-1);
%                 restY=leftHandY(ii-1);
%                 restZ=leftHandZ(ii-1);
%                 break;
%             end          
%         end
%         
%         for iii=a:alpha
%             disX=abs(leftHandX(iii)-restX);
%             disY=abs(leftHandY(iii)-restY);
%             disZ=abs(leftHandZ(iii)-restZ);
%             if ((disX>=thresh)||(disY>=thresh)||(disZ>=thresh))
%                 reactionTime(1,i)=leftHandTime(iii)-startTime;
%                 reactionTime(2,i)=0; % 0 means left hand here
%                 completionTime(2,i)=0; % 0 means left hand here
%                 b=iii;
%                 break;
%             end
%         end
%     end
%     
%     for ii=b:alpha
%         if (rightHandTime(ii)> endTime)
%             handIndex=ii;
%             break;
%         end          
%     end
%     
% end
% 
% disp('reactionTime is');
%disp(reactionTime);
%get the time_stamp startTime

%get the first target in collisionData

%get the time_stamp endTime

%within the moving hand transform, from i=1, compare time_stamp with startTime,
%if time_stamp[i]>startTime, give a=i-1, start to compare time_series(a)and
%time_series(a+1), if time_series(i)>time_series(a)+0.001 &&time_stamps(i)<endTIme,
% time_stamps(i)-time_stamps(a)= reaction time

% section 5. sort the reaction time data
% TL1_Time=zeros(3,14); % (1,:)will be reaction time and (2,:)will be completion time (3,:)will be left hand or right hand
% TL2_Time=zeros(3,14);
% TL3_Time=zeros(3,14);
% TL4_Time=zeros(3,14);
% TL5_Time=zeros(3,14);
% TL6_Time=zeros(3,14);
% TL7_Time=zeros(3,14);
% TL8_Time=zeros(3,14);
% TL9_Time=zeros(3,14);
% TL10_Time=zeros(3,14);
% TL11_Time=zeros(3,14);
% TL12_Time=zeros(3,14);
% TL13_Time=zeros(3,14);
% TL14_Time=zeros(3,14);
% left_Time=zeros(2,14);
% right_Time=zeros(2,14);
% count=zeros(1,14);
% 
% for i=1:100
%     target=spawnData(i);
%     switch target{1}
%         case 'TL1'
%             count(1)=count(1)+1;
%             TL1_Time(1,count(1))=reactionTime(1,i);
%             TL1_Time(2,count(1))=completionTime(1,i);
%             TL1_Time(3,count(1))=completionTime(2,i);
%         case 'TL2'
%             count(2)=count(2)+1;
%             TL2_Time(1,count(2))=reactionTime(1,i);
%             TL2_Time(2,count(2))=completionTime(1,i);
%             TL2_Time(3,count(2))=completionTime(2,i);
%         case 'TL3'
%             count(3)=count(3)+1;
%             TL3_Time(1,count(3))=reactionTime(1,i);
%             TL3_Time(2,count(3))=completionTime(1,i);
%             TL3_Time(3,count(3))=completionTime(2,i);
%         case 'TL4'
%             count(4)=count(4)+1;
%             TL4_Time(1,count(4))=reactionTime(1,i);
%             TL4_Time(2,count(4))=completionTime(1,i);
%             TL4_Time(3,count(4))=completionTime(2,i);
%         case 'TL5'
%             count(5)=count(5)+1;
%             TL5_Time(1,count(5))=reactionTime(1,i);
%             TL5_Time(2,count(5))=completionTime(1,i);
%             TL5_Time(3,count(5))=completionTime(2,i);
%         case 'TL6'
%             count(6)=count(6)+1;
%             TL6_Time(1,count(6))=reactionTime(1,i);
%             TL6_Time(2,count(6))=completionTime(1,i);
%             TL6_Time(3,count(6))=completionTime(2,i);
%         case 'TL7'
%             count(7)=count(7)+1;
%             TL7_Time(1,count(7))=reactionTime(1,i);
%             TL7_Time(2,count(7))=completionTime(1,i);
%             TL7_Time(3,count(7))=completionTime(2,i);
%         case 'TL8'
%             count(8)=count(8)+1;
%             TL8_Time(1,count(8))=reactionTime(1,i);
%             TL8_Time(2,count(8))=completionTime(1,i);
%             TL8_Time(3,count(8))=completionTime(2,i);
%         case 'TL9'
%             count(9)=count(9)+1;
%             TL9_Time(1,count(9))=reactionTime(1,i);
%             TL9_Time(2,count(9))=completionTime(1,i);
%             TL9_Time(3,count(9))=completionTime(2,i);
%         case 'TL10'
%             count(10)=count(10)+1;
%             TL10_Time(1,count(10))=reactionTime(1,i);
%             TL10_Time(2,count(10))=completionTime(1,i);
%             TL10_Time(3,count(10))=completionTime(2,i);
%         case 'TL11'
%             count(11)=count(11)+1;
%             TL11_Time(1,count(11))=reactionTime(1,i);
%             TL11_Time(2,count(11))=completionTime(1,i);
%             TL11_Time(3,count(11))=completionTime(2,i);
%         case 'TL12'
%             count(12)=count(12)+1;
%             TL12_Time(1,count(12))=reactionTime(1,i);
%             TL12_Time(2,count(12))=completionTime(1,i);
%             TL12_Time(3,count(12))=completionTime(2,i);
%         case 'TL13'
%             count(13)=count(13)+1;
%             TL13_Time(1,count(13))=reactionTime(1,i);
%             TL13_Time(2,count(13))=completionTime(1,i);
%             TL13_Time(3,count(13))=completionTime(2,i);
%         case 'TL14'
%             count(14)=count(14)+1;
%             TL14_Time(1,count(14))=reactionTime(1,i);
%             TL14_Time(2,count(14))=completionTime(1,i);
%             TL14_Time(3,count(14))=completionTime(2,i);
%     end           
% end
% 
% TL1_Time=(TL1_Time(:,1:(count(1))));%disp('TL1 time is');disp(TL1_Time);
% TL2_Time=(TL2_Time(:,1:(count(2))));%disp('TL2 time is');disp(TL2_Time);
% TL3_Time=(TL3_Time(:,1:(count(3))));%disp('TL3 time is');disp(TL3_Time);
% TL4_Time=(TL4_Time(:,1:(count(4))));%disp('TL4 time is');disp(TL4_Time);
% TL5_Time=(TL5_Time(:,1:(count(5))));%disp('TL5 time is');disp(TL5_Time);
% TL6_Time=(TL6_Time(:,1:(count(6))));%disp('TL6 time is');disp(TL6_Time);
% TL7_Time=(TL7_Time(:,1:(count(7))));%disp('TL7 time is');disp(TL7_Time);
% TL8_Time=(TL8_Time(:,1:(count(8))));%disp('TL8 time is');disp(TL8_Time);
% TL9_Time=(TL9_Time(:,1:(count(9))));%disp('TL9 time is');disp(TL9_Time);
% TL10_Time=(TL10_Time(:,1:(count(10))));%disp('TL10 time is');disp(TL10_Time);
% TL11_Time=(TL11_Time(:,1:(count(11))));%disp('TL11 time is');disp(TL11_Time);
% TL12_Time=(TL12_Time(:,1:(count(12))));%disp('TL12 time is');disp(TL12_Time);
% TL13_Time=(TL13_Time(:,1:(count(13))));%disp('TL13 time is');disp(TL13_Time);
% TL14_Time=(TL14_Time(:,1:(count(14))));%disp('TL14 time is');disp(TL14_Time);
% 
% 
% % Calculation for group bar plot for all locations 
% TL1_1=TL1_Time(1,:);
% TL1_2=TL1_Time(2,:);
% rMTL1(1,block)= mean(TL1_1);
% rST_TL1(1,block) = std(TL1_1);
% cMTL1(1,block)= mean(TL1_2);
% cST_TL1(1,block) = std(TL1_2);
% 
% TL2_1=TL2_Time(1,:);
% TL2_2=TL2_Time(2,:);
% rMTL2(1,block)= mean(TL2_1);
% rST_TL2(1,block) = std(TL2_1);
% cMTL2(1,block)= mean(TL2_2);
% cST_TL2(1,block) = std(TL2_2);
% 
% TL3_1=TL3_Time(1,:);
% TL3_2=TL3_Time(2,:);
% rMTL3(1,block)= mean(TL3_1);
% rST_TL3(1,block) = std(TL3_1);
% cMTL3(1,block)= mean(TL3_2);
% cST_TL3(1,block) = std(TL3_2);
% 
% TL4_1=TL4_Time(1,:);
% TL4_2=TL4_Time(2,:);
% rMTL4(1,block)= mean(TL4_1);
% rST_TL4(1,block) = std(TL4_1);
% cMTL4(1,block)= mean(TL4_2);
% cST_TL4(1,block) = std(TL4_2);
% 
% TL5_1=TL5_Time(1,:);
% TL5_2=TL5_Time(2,:);
% rMTL5(1,block)= mean(TL5_1);
% rST_TL5(1,block) = std(TL5_1);
% cMTL5(1,block)= mean(TL5_2);
% cST_TL5(1,block) = std(TL5_2);
% 
% TL6_1=TL6_Time(1,:);
% TL6_2=TL6_Time(2,:);
% rMTL6(1,block)= mean(TL6_1);
% rST_TL6(1,block) = std(TL6_1);
% cMTL6(1,block)= mean(TL6_2);
% cST_TL6(1,block) = std(TL6_2);
% 
% TL7_1=TL7_Time(1,:);
% TL7_2=TL7_Time(2,:);
% rMTL7(1,block)= mean(TL7_1);
% rST_TL7(1,block) = std(TL7_1);
% cMTL7(1,block)= mean(TL7_2);
% cST_TL7(1,block) = std(TL7_2);
% 
% TL8_1=TL1_Time(1,:);
% TL8_2=TL1_Time(2,:);
% rMTL8(1,block)= mean(TL8_1);
% rST_TL8(1,block) = std(TL8_1);
% cMTL8(1,block)= mean(TL8_2);
% cST_TL8(1,block) = std(TL8_2);
% 
% TL9_1=TL9_Time(1,:);
% TL9_2=TL9_Time(2,:);
% rMTL9(1,block)= mean(TL9_1);
% rST_TL9(1,block) = std(TL9_1);
% cMTL9(1,block)= mean(TL9_2);
% cST_TL9(1,block) = std(TL9_2);
% 
% TL10_1=TL10_Time(1,:);
% TL10_2=TL10_Time(2,:);
% rMTL10(1,block)= mean(TL10_1);
% rST_TL10(1,block) = std(TL10_1);
% cMTL10(1,block)= mean(TL10_2);
% cST_TL10(1,block) = std(TL10_2);
% 
% TL11_1=TL11_Time(1,:);
% TL11_2=TL11_Time(2,:);
% rMTL11(1,block)= mean(TL11_1);
% rST_TL11(1,block) = std(TL11_1);
% cMTL11(1,block)= mean(TL11_2);
% cST_TL11(1,block) = std(TL11_2);
% 
% TL12_1=TL12_Time(1,:);
% TL12_2=TL12_Time(2,:);
% rMTL12(1,block)= mean(TL12_1);
% rST_TL12(1,block) = std(TL12_1);
% cMTL12(1,block)= mean(TL12_2);
% cST_TL12(1,block) = std(TL12_2);
% 
% TL13_1=TL13_Time(1,:);
% TL13_2=TL13_Time(2,:);
% rMTL13(1,block)= mean(TL13_1);
% rST_TL13(1,block) = std(TL13_1);
% cMTL13(1,block)= mean(TL13_2);
% cST_TL13(1,block) = std(TL13_2);
% 
% TL14_1=TL14_Time(1,:);
% TL14_2=TL14_Time(2,:);
% rMTL14(1,block)= mean(TL14_1);
% rST_TL14(1,block) = std(TL14_1);
% cMTL14(1,block)= mean(TL14_2);
% cST_TL14(1,block) = std(TL14_2);

% tarRightPercent_3Bl(block,:)=tarRightPercent;

%{
if (block ==1)
figure (1); title('Shoulder Level Block 1');labels = {'Left Hand Use','Right Hand Use'};legend(labels,'Location','southoutside','Orientation','horizontal');
colormap([0 1 1; 1 1 0]); set(gcf,'color','w');
X1=[(1-lowRightPercent(1)),lowRightPercent(1)]; X2=[(1-lowRightPercent(2)),lowRightPercent(2)];X3=[(1-lowRightPercent(3)),lowRightPercent(3)];
X4=[(1-lowRightPercent(4)),lowRightPercent(4)]; X5=[(1-lowRightPercent(5)),lowRightPercent(5)];X6=[(1-lowRightPercent(6)),lowRightPercent(6)]; 
X7=[(1-lowRightPercent(7)),lowRightPercent(7)];
subplot(1,7,1); pie(X1);subplot(1,7,2); pie(X2);subplot(1,7,3); pie(X3);subplot(1,7,4); pie(X4);
subplot(1,7,5); pie(X5);subplot(1,7,6); pie(X6);subplot(1,7,7); pie(X7);

figure (2);title('Higher Level Block 1');colormap([0 1 1; 1 1 0]); set(gcf,'color','w');
X1=[(1-highRightPercent(1)),highRightPercent(1)];X2=[(1-highRightPercent(2)),highRightPercent(2)]; X3=[(1-highRightPercent(3)),highRightPercent(3)];
X4=[(1-highRightPercent(4)),highRightPercent(4)];X5=[(1-highRightPercent(5)),highRightPercent(5)]; X6=[(1-highRightPercent(6)),highRightPercent(6)];
X7=[(1-highRightPercent(7)),highRightPercent(7)];
subplot(1,7,1); pie(X1);subplot(1,7,2); pie(X2);subplot(1,7,3); pie(X3);subplot(1,7,4); pie(X4);
subplot(1,7,5); pie(X5);subplot(1,7,6); pie(X6);subplot(1,7,7); pie(X7);
%subplot(2,4,1); pie(X1);subplot(2,4,2); pie(X2);subplot(2,4,3); pie(X3);subplot(2,4,4); pie(X4);
%subplot(2,4,5); pie(X5);subplot(2,4,6); pie(X6);subplot(2,4,7); pie(X7);
end

if (block==2)
    figure (3); title('Shoulder Level Block 2');labels = {'Left Hand Use','Right Hand Use'};legend(labels,'Location','southoutside','Orientation','horizontal');
colormap([0 1 1; 1 1 0]); set(gcf,'color','w');
X1=[(1-lowRightPercent(1)),lowRightPercent(1)]; X2=[(1-lowRightPercent(2)),lowRightPercent(2)];X3=[(1-lowRightPercent(3)),lowRightPercent(3)];
X4=[(1-lowRightPercent(4)),lowRightPercent(4)]; X5=[(1-lowRightPercent(5)),lowRightPercent(5)];X6=[(1-lowRightPercent(6)),lowRightPercent(6)]; 
X7=[(1-lowRightPercent(7)),lowRightPercent(7)];
subplot(1,7,1); pie(X1);subplot(1,7,2); pie(X2);subplot(1,7,3); pie(X3);subplot(1,7,4); pie(X4);
subplot(1,7,5); pie(X5);subplot(1,7,6); pie(X6);subplot(1,7,7); pie(X7);
%subplot(2,4,1); pie(X1);subplot(2,4,2); pie(X2);subplot(2,4,3); pie(X3);subplot(2,4,4); pie(X4);
%subplot(2,4,5); pie(X5);subplot(2,4,6); pie(X6);subplot(2,4,7); pie(X7);

figure (4);title('Higher Level Block 2');colormap([0 1 1; 1 1 0]); set(gcf,'color','w');
X1=[(1-highRightPercent(1)),highRightPercent(1)];X2=[(1-highRightPercent(2)),highRightPercent(2)]; X3=[(1-highRightPercent(3)),highRightPercent(3)];
X4=[(1-highRightPercent(4)),highRightPercent(4)];X5=[(1-highRightPercent(5)),highRightPercent(5)]; X6=[(1-highRightPercent(6)),highRightPercent(6)];
X7=[(1-highRightPercent(7)),highRightPercent(7)];
subplot(1,7,1); pie(X1);subplot(1,7,2); pie(X2);subplot(1,7,3); pie(X3);subplot(1,7,4); pie(X4);
subplot(1,7,5); pie(X5);subplot(1,7,6); pie(X6);subplot(1,7,7); pie(X7);
%subplot(2,4,1); pie(X1);subplot(2,4,2); pie(X2);subplot(2,4,3); pie(X3);subplot(2,4,4); pie(X4);
%subplot(2,4,5); pie(X5);subplot(2,4,6); pie(X6);subplot(2,4,7); pie(X7);

end

if (block==3)
   figure (5); title('Shoulder Level Block 3');labels = {'Left Hand Use','Right Hand Use'};legend(labels,'Location','southoutside','Orientation','horizontal');
colormap([0 1 1; 1 1 0]); set(gcf,'color','w');
X1=[(1-lowRightPercent(1)),lowRightPercent(1)]; X2=[(1-lowRightPercent(2)),lowRightPercent(2)];X3=[(1-lowRightPercent(3)),lowRightPercent(3)];
X4=[(1-lowRightPercent(4)),lowRightPercent(4)]; X5=[(1-lowRightPercent(5)),lowRightPercent(5)];X6=[(1-lowRightPercent(6)),lowRightPercent(6)]; 
X7=[(1-lowRightPercent(7)),lowRightPercent(7)];
subplot(1,7,1); pie(X1);subplot(1,7,2); pie(X2);subplot(1,7,3); pie(X3);subplot(1,7,4); pie(X4);
subplot(1,7,5); pie(X5);subplot(1,7,6); pie(X6);subplot(1,7,7); pie(X7);
%subplot(2,4,1); pie(X1);subplot(2,4,2); pie(X2);subplot(2,4,3); pie(X3);subplot(2,4,4); pie(X4);
%subplot(2,4,5); pie(X5);subplot(2,4,6); pie(X6);subplot(2,4,7); pie(X7);

figure (6);title('Higher Level Block 3');colormap([0 1 1; 1 1 0]); set(gcf,'color','w');
X1=[(1-highRightPercent(1)),highRightPercent(1)];X2=[(1-highRightPercent(2)),highRightPercent(2)]; X3=[(1-highRightPercent(3)),highRightPercent(3)];
X4=[(1-highRightPercent(4)),highRightPercent(4)];X5=[(1-highRightPercent(5)),highRightPercent(5)]; X6=[(1-highRightPercent(6)),highRightPercent(6)];
X7=[(1-highRightPercent(7)),highRightPercent(7)];
subplot(1,7,1); pie(X1);subplot(1,7,2); pie(X2);subplot(1,7,3); pie(X3);subplot(1,7,4); pie(X4);
subplot(1,7,5); pie(X5);subplot(1,7,6); pie(X6);subplot(1,7,7); pie(X7);
%subplot(2,4,1); pie(X1);subplot(2,4,2); pie(X2);subplot(2,4,3); pie(X3);subplot(2,4,4); pie(X4);
%subplot(2,4,5); pie(X5);subplot(2,4,6); pie(X6);subplot(2,4,7); pie(X7);
end

%}

for i = 1 : 14
    eval(['TvB' num2str(block) '_L{i} = T' num2str(i) '_B' num2str(block) 'L;']);
    eval(['TvB' num2str(block) '_R{i} = T' num2str(i) '_B' num2str(block) 'R;']);
end
eval(['TvB_P0' num2str(pid) '{block,1}=TvB' num2str(block) '_L']);
eval(['TvB_P0' num2str(pid) '{block,2}=TvB' num2str(block) '_R']);
% R_MTL_all=[rMTL1; rMTL2; rMTL3; rMTL4; rMTL5; rMTL6; rMTL7; rMTL8; rMTL9;
% rMTL10; rMTL11; rMTL12; rMTL13; rMTL14];
% R_ST_TL_all=[rST_TL1;rST_TL2;rST_TL3;rST_TL4;rST_TL5;rST_TL6;rST_TL7;rST_TL8;rST_TL9;rST_TL10;rST_TL11;rST_TL12;rST_TL13;rST_TL14];
% C_MTL_all=[cMTL1; cMTL2; cMTL3; cMTL4; cMTL5; cMTL6; cMTL7; cMTL8; cMTL9;
% cMTL10; cMTL11; cMTL12; cMTL13; cMTL14];
% C_ST_TL_all=[cST_TL1;cST_TL2;cST_TL3;cST_TL4;cST_TL5;cST_TL6;cST_TL7;cST_TL8;cST_TL9;cST_TL10;cST_TL11;cST_TL12;cST_TL13;cST_TL14];
end
tarRightPercent_3Bl=tarRightPercent_3Bl.'
OrgData_Str{pid}=OrgData;
xlswrite(['P' spid '.xlsx'],OrgData);

AllSubjectsData = [AllSubjectsData;OrgData];

save(['TvB_P0' num2str(pid) '.mat'],['TvB_P0' num2str(pid)])
end
xlswrite('AllSubjectsData1.xlsx', AllSubjectsData);

%figure (1); title('P01 right hand Velocity target 5');plot(TvB_P01{1,2}{1,5});hold on; plot(TvB_P01{2,2}{1,5});hold on; plot(TvB_P01{3,2}{1,5}); legend('B01','B02','B03')

%{
figure (1); bar(R_MTL_all);title('Reaction Time for ALL target locaitons');xlabel('Target Locations');ylabel('Reaction Time (sec)');
legend('Block 1','Block 2','Block 3');ylim([0 1.0]);

figure (2); x=1:2:14; bar(x,R_MTL_all([1 3 5 7 9 11 13],:)); title('Reaction Time for higher level target locaitons');xlabel('Target Locations');ylabel('Reaction Time (sec)');
legend('Block 1','Block 2','Block 3');ylim([0 1.0]);

figure (3); x=2:2:14; bar(x,R_MTL_all([2 4 6 8 10 12 14],:)); title('Reaction Time for shoulder level target locaitons');xlabel('Target Locations');ylabel('Reaction Time (sec)');
legend('Block 1','Block 2','Block 3');ylim([0 1.0]);


figure (4);bar(C_MTL_all);title('Completion Time for ALL target locaitons');xlabel('Target Locations');ylabel('Completion Time (sec)');
legend('Block 1','Block 2','Block 3');ylim([0 1.5]);

figure (5);x=1:2:14; bar(x,C_MTL_all([1 3 5 7 9 11 13],:)); title('Completion Time for higher level target locaitons');xlabel('Target Locations');ylabel('Completion Time (sec)');
legend('Block 1','Block 2','Block 3');ylim([0 1.5]);

figure (6);x=2:2:14; bar(x,C_MTL_all([2 4 6 8 10 12 14],:)); title('Completion Time for shoulder level target locaitons');xlabel('Target Locations');ylabel('Completion Time (sec)');
legend('Block 1','Block 2','Block 3');ylim([0 1.5]);

figure (7); bar (tarRightPercent_3Bl); title('Right Hand Percent for ALL target locaitons');xlabel('Target Locations');ylabel('Right Hand Use Pencentage');
legend('Block 1','Block 2','Block 3'); ylim([0 1.2]);
%}

% next, how to add errbar to the graph and make the graph looks better


% Seperate 

%{
some example code
ngroups = size(y, 1);
nbars = size(y, 2);
% Calculating the width for each bar group
groupwidth = min(0.8, nbars/(nbars + 1.5));
for i = 1:nbars
    x = (1:ngroups) - groupwidth/2 + (2*i-1) * groupwidth / (2*nbars);
    errorbar(x, y(:,i), err(:,i), '.');
end
hold off
%}
% end

